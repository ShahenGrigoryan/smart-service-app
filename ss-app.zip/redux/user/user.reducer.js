import { Toast } from 'native-base';
import * as Actions from './user.actions';

const initialState = {
  isLoggedIn: false,
  loading: false,
};

const userReducer = (state = initialState, action) => {
  const newState = { ...state };
  switch (action.type) {
    case Actions.LOGIN_SUCCESS: {
      return {
        ...newState,
        isLoggedIn: true,
        token: action.data.token,
        ...action.data.user,
        loading: false,
      };
    }
    case Actions.LOGIN_FAILURE: {
      Toast.show({
        text: action.err, type: 'danger', position: 'top', textStyle: { textAlign: 'center' },
      });
      return { ...newState, isLoggedIn: false, loading: false };
    }
    case Actions.LOGOUT_SUCCESS: {
      return { isLoggedIn: false, loading: false };
    }
    case Actions.SET_DRAWER: {
      newState.drawer = action.drawer;
      return newState;
    }
    case Actions.START_LOADING: {
      return { ...newState, loading: true };
    }
    default: {
      return state;
    }
  }
};

export default userReducer;
