import {
  put, takeLatest, all, call,
} from 'redux-saga/effects';
import * as UserActions from './user.actions';
import * as Api from '../../api/api';
import { setNotFirst } from '../visit/visit.actions';
import { logoutSuccess } from './user.actions';
import { nullify } from '../tasks/tasks.actions';
import * as PageActions from '../pages/pages.actions';

function* login(action) {
  yield put(UserActions.startLoading());
  try {
    const userInfo = yield Api.login(action.user);
    yield put(setNotFirst());
    yield put(UserActions.loginSuccess(userInfo.data));
    yield put(PageActions.endLoading());
  } catch (e) {
    if (e?.response?.status === 401) {
      yield put(UserActions.loginFailure('Неправильный логин или пароль'));
    } else {
      yield put(UserActions.loginFailure('Что-то пошло не так'));
    }
  }
}

function* logout({ token }) {
  try {
    yield Api.logout(token);
    yield put(logoutSuccess());
    yield put(nullify());
  } catch (e) {
    console.log('error', e);
  }
}

function* loginStart() {
  yield takeLatest(UserActions.LOGIN_START, login);
}
function* logoutStart() {
  yield takeLatest(UserActions.LOGOUT, logout);
}

function* loginSaga() {
  yield all([call(loginStart), call(logoutStart)]);
}

export default loginSaga;
