export const LOGIN_START = 'LOGIN_START';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const START_LOADING = 'START_LOADING';
export const LOGOUT = 'LOGOUT';
export const LOGOUT_SUCCESS = 'LOGOUT_SUCCESS';
export const SET_DRAWER = 'SET_DRAWER';

export const login = (user) => ({
  type: LOGIN_START,
  user,
});
export const loginSuccess = (data) => ({
  type: LOGIN_SUCCESS,
  data,
});
export const loginFailure = (err) => ({
  type: LOGIN_FAILURE,
  err,
});

export const logout = (token) => ({
  type: LOGOUT,
  token,
});
export const setDrawer = () => ({
  type: SET_DRAWER,
});

export const startLoading = () => ({
  type: START_LOADING,
});

export const logoutSuccess = () => ({
  type: LOGOUT_SUCCESS,
});
