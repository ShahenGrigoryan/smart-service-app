import {
  put, takeLatest, all, call,
} from 'redux-saga/effects';
import * as Api from '../../api/api';
import * as TasksActions from './tasks.actions';
import * as PageActions from '../pages/pages.actions';
import * as UserActions from '../user/user.actions';
import { updateCheckListItemSuccess, updateTaskSuccess } from './tasks.actions';

function* getTasks({ token }) {
  yield put(PageActions.startLoading());
  try {
    const tasks = yield Api.getTasks(token);
    yield put(TasksActions.getTasksSuccess(tasks.data.data));
    yield put(PageActions.endLoading());
  } catch (e) {
    yield put(PageActions.endLoading());
    if (e?.response?.status === 401) {
      yield put(UserActions.loginFailure(e.message));
    } else {
      yield put(PageActions.pageFailure(e.message));
    }
  }
}

function* getCurrentTask({ token, id }) {
  console.log('getting current task');
  try {
    yield put(PageActions.startLoading());
    const currentTask = yield Api.getCurrentTask(token, id);
    yield put(TasksActions.getCurrentTaskSuccess(currentTask?.data?.data));
    yield put(PageActions.endLoading());
  } catch (e) {
    yield put(PageActions.endLoading());
    if (e?.response?.status === 401) {
      yield put(UserActions.loginFailure(e.message));
    } else {
      yield put(PageActions.pageFailure(e.message));
    }
  }
}

function* createTaskComment({ token, taskId, comment }) {
  try {
    const newComment = yield Api.createTaskComment(token, taskId, comment);
    yield Api.getTaskComments(token, taskId);
    yield put(TasksActions.createTaskCommentSuccess(newComment.data.data));
  } catch (e) {
    if (e.response.status === 401) {
      yield put(UserActions.loginFailure(e.message));
    } else {
      yield put(PageActions.pageFailure(e.message));
    }
  }
}

function* updateCheckListItem(data) {
  try {
    yield put(PageActions.startLoading());
    const newCheckListItem = yield Api.updateCheckListItem(data);
    yield put(updateCheckListItemSuccess({
      newCheckListItem: newCheckListItem.data.data,
      ...data,
    }));
    yield put(PageActions.endLoading());
  } catch (e) {
    yield put(PageActions.endLoading());
    if (e.response.status === 401) {
      yield put(UserActions.loginFailure(e.message));
    } else {
      yield put(PageActions.pageFailure(e.message));
    }
  }
}

function* updateTask({ token, body, id }) {
  try {
    yield put(PageActions.startLoading());
    console.log('send data', { token, body, id });
    const updatedTask = yield Api.updateTask({ token, body, id });
    yield put(updateTaskSuccess({ data: updatedTask.data.data, id }));
    yield put(PageActions.endLoading());
  } catch (e) {
    yield put(PageActions.endLoading());
    if (e?.response?.status === 401) {
      yield put(UserActions.loginFailure(e.message));
    } else {
      yield put(PageActions.pageFailure(e.message));
    }
  }
}

function* getTasksStart() {
  yield takeLatest(TasksActions.GET_TASKS_START, getTasks);
}

function* getCurrentTaskStart() {
  yield takeLatest(TasksActions.GET_CURRENT_TASK_START, getCurrentTask);
}
function* createTaskCommentStart() {
  yield takeLatest(TasksActions.CREATE_TASK_COMMENT_START, createTaskComment);
}
function* updateCheckListItemStart() {
  yield takeLatest(TasksActions.UPDATE_CHECKLIST_ITEM_START, updateCheckListItem);
}
function* updateTaskStart() {
  yield takeLatest(TasksActions.UPDATE_TASK_START, updateTask);
}

function* tasksSaga() {
  yield all([
    call(getTasksStart),
    call(getCurrentTaskStart),
    call(createTaskCommentStart),
    call(updateCheckListItemStart),
    call(updateTaskStart),
  ]);
}

export default tasksSaga;
