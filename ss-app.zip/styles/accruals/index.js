import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  colTitle: {
    color: '#a8a8a8',
  },
  colText: {

  },
});

export default styles;
