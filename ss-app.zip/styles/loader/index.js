import { StyleSheet, Dimensions } from 'react-native';

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    zIndex: 99,
    backgroundColor: 'rgba(0,0,0,0.5)',
    width: '100%',
    height: Dimensions.get('window').height,
    justifyContent: 'center',
  },
});

export default styles;
