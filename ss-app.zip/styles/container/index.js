import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  root: {
    paddingHorizontal: 5,
    paddingVertical: 15,
    paddingTop: 5,
  },
});

export default styles;
