import React, { useState, useEffect } from 'react';
import {
  View, Text, Content, Card, Button, Textarea, ActionSheet,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

import {useDispatch, useSelector} from 'react-redux';
import AppCardStyles from '../../styles/appCard';
import CameraWrapper from '../../components/CameraWrapper';
import PagesBackground from '../../components/PagesBackground';
import { getCurrentTaskStart } from '../../redux/tasks/tasks.actions';
import {getCurrentTicketStart} from "../../redux/tickets/tickets.actions";

const ApplicationCard = ({ navigation, route }) => {
  const { ticket } = route?.params;
  const dispatch = useDispatch()
  const [image, setImage] = useState('');
  const token = useSelector((state) => state.user.token);
  const current_ticket = useSelector((state) => state.tickets.current_ticket);
  const statuses = [
    { text: 'В работе', color: '#ef820d' },
    { text: 'Приступил к выполнению', color: '#ef820d' },
    { text: 'Выполнен', color: '#05b41c' },
    { text: 'Отменён', color: '#ec4034' },
    { text: 'Переведен в Заказ', color: '#7735d2' },
    { text: 'Закрыть' },
  ];
  const [status, setStatus] = useState(statuses[0]);
  useEffect(() => {
    dispatch(getCurrentTicketStart(token, ticket.id));
  }, []);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const [cameraOpen, setCameraOpen] = useState(false);

  return (
    <CameraWrapper open={cameraOpen}>
      <PagesBackground>
        <Content style={{ height: '100%' }}>
          <TouchableOpacity style={AppCardStyles.backButton} onPress={() => navigation.goBack()}>
            <MaterialIcons name="arrow-back" size={30} color="black" />
          </TouchableOpacity>
          <View style={{
            ...AppCardStyles.header, maxWidth: '80%', flexWrap: 'wrap', alignSelf: 'center',
          }}
          >

            <Text style={{
              fontSize: 20, fontWeight: 'bold', marginRight: 10, marginBottom: 10,
            }}
            >
              Статус:
            </Text>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => ActionSheet.show(
                {
                  options: statuses,
                  // cancelButtonIndex: 3,
                  destructiveButtonIndex: 5,
                },
                (buttonIndex) => {
                  if (buttonIndex !== 5) { setStatus(statuses[buttonIndex]); }
                },
              )}
            >
              <Text style={{
                paddingVertical: 8, paddingHorizontal: 12, backgroundColor: status.color, color: '#fff', borderRadius: 5,
              }}
              >
                {status.text}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={{ ...AppCardStyles.card }}>
            <Card style={AppCardStyles.card}>
              <Text style={AppCardStyles.title}>
                Тема заявки:
              </Text>
              <Text style={AppCardStyles.content}>
                IM-2325702 Замена плитки
              </Text>
            </Card>
            <Card style={AppCardStyles.card}>
              <Text style={AppCardStyles.title}>
                Описание:
              </Text>
              <Text style={AppCardStyles.content}>
                Прошу произвести замену потолочной плитки,
                в которой встроены пожарные датчики, она повреждена была водой.
                Новая плитка лежит за потолком в местах где необходимо
              </Text>
            </Card>
            <Card style={AppCardStyles.card}>
              <Text>
                Инициатор: Иванов Иван
              </Text>
              <Text>
                Наблюдатель: Панова Ольга
              </Text>
              <Text>
                Исполнитель: Ручкин Антон
              </Text>
              <Text>
                От заказчика: Сидоров Максим
              </Text>
            </Card>
          </View>
          <View>
            <View style={{ flexDirection: 'row', paddingHorizontal: 10 }}>
              <TouchableOpacity onPress={pickImage}>
                <MaterialIcons name="attach-file" size={35} color="black" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setCameraOpen(true)}>
                <MaterialIcons name="photo-camera" size={35} color="black" />
              </TouchableOpacity>
            </View>
            <Textarea
              bordered
              style={{
                paddingHorizontal: 10, marginHorizontal: 20, marginBottom: 10, paddingVertical: 5, backgroundColor: '#fff', height: 120, borderRadius: 10,
              }}
            />
            <Button style={AppCardStyles.addButton}>
              <Text>
                Добавить
              </Text>
            </Button>
          </View>
        </Content>
      </PagesBackground>
    </CameraWrapper>

  );
};

export default ApplicationCard;
