import React from 'react';
import { TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import {
  Text, Content, View, Grid, Col, Row,
} from 'native-base';
import AppCardStyles from '../../styles/appCard';
import CheckListStyles from '../../styles/checkLists';
import AccrualStyles from '../../styles/accruals';
import MonthPicker from '../../components/MonthPicker';
import PagesBackground from '../../components/PagesBackground';

const Accruals = ({ navigation }) => (
  <PagesBackground>
    <View style={CheckListStyles.header}>
      <TouchableOpacity style={AppCardStyles.backButton} onPress={() => navigation.goBack()}>
        <MaterialIcons name="arrow-back" size={30} color="black" />
      </TouchableOpacity>
      <View style={CheckListStyles.headerTextView}>
        <Text style={CheckListStyles.headerText}>
          Начисления
        </Text>

      </View>
    </View>
    <MonthPicker />
    <Content>
      <View style={{ flexDirection: 'row', paddingHorizontal: 25 }}>
        <Grid>
          <Row>
            <Col>
              <Text style={AccrualStyles.colTitle}>К выплате</Text>
              <Text>0 Р</Text>
            </Col>
            <Col>
              <Text style={AccrualStyles.colTitle}>Начислено</Text>
              <Text>0 Р</Text>
            </Col>
            <Col>
              <Text style={AccrualStyles.colTitle}>Штрафы</Text>
              <Text>0 Р</Text>
            </Col>
          </Row>
        </Grid>
      </View>
      <View style={{ flexDirection: 'row', paddingHorizontal: 5 }}>
        <Grid style={{
          borderStyle: 'solid', borderColor: '#a8a8a8', borderWidth: 1, marginTop: 20,
        }}
        >
          <Row style={{ borderStyle: 'solid', borderColor: '#a8a8a8', borderBottomWidth: 1 }}>
            <Col style={{
              width: '40%', borderStyle: 'solid', borderColor: '#a8a8a8', borderRightWidth: 1, paddingVertical: 8, paddingLeft: 3,
            }}
            >
              <Text style={AccrualStyles.colTitle}>Начисления</Text>
            </Col>
            <Col style={{
              width: '40%', borderStyle: 'solid', borderColor: '#a8a8a8', borderRightWidth: 1, paddingVertical: 8, paddingLeft: 3,
            }}
            >
              <Text style={AccrualStyles.colTitle}>Базовый оклад</Text>

            </Col>
            <Col style={{ paddingVertical: 8, paddingLeft: 3 }}>
              <Text style={AccrualStyles.colTitle}>Бонусы</Text>
            </Col>
          </Row>
          <Row style={{ borderStyle: 'solid', borderColor: '#a8a8a8', borderBottomWidth: 1 }}>
            <Col style={{
              width: '40%', borderStyle: 'solid', borderColor: '#a8a8a8', borderRightWidth: 1, paddingVertical: 8, paddingLeft: 3,
            }}
            >
              <Text>5000</Text>
            </Col>
            <Col style={{
              width: '40%', borderStyle: 'solid', borderColor: '#a8a8a8', borderRightWidth: 1, paddingVertical: 8, paddingLeft: 3,
            }}
            >
              <Text>1000</Text>

            </Col>
            <Col style={{ paddingVertical: 8, paddingLeft: 3 }}>
              <Text>350</Text>

            </Col>
          </Row>
        </Grid>
      </View>

    </Content>
  </PagesBackground>
);

export default Accruals;
