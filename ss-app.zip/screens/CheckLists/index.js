import React from 'react';
import {
  Card, Content, Text, View,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSelector } from 'react-redux';
import AppCardStyles from '../../styles/appCard';
import CardStyles from '../../styles/card';
import CheckListStyles from '../../styles/checkLists';
import CheckListItem from '../../components/CheckListItem';
import PagesBackground from '../../components/PagesBackground';

const CheckLists = ({ navigation, route }) => {
  const { data, type } = route?.params;
  const checkList = useSelector((state) => state.tasks?.current_task?.task_todos);
  return (
    <PagesBackground>
      <Content>
        <View style={CheckListStyles.header}>
          <TouchableOpacity style={AppCardStyles.backButton} onPress={() => navigation.goBack()}>
            <MaterialIcons name="arrow-back" size={30} color="black" />
          </TouchableOpacity>
          <View style={CheckListStyles.headerTextView}>
            <Text style={CheckListStyles.headerText}>
              Чек листы
              {' '}
              {type === 'task' ? 'задачи' : type === 'application' ? 'заявки' : type === 'check' ? 'проверки' : ''}
            </Text>
            <Text style={CheckListStyles.numberText}>
              №
              {' '}
              {data.id}
            </Text>
          </View>
        </View>
        <View style={CheckListStyles.listsDescription}>
          <Text style={{ fontWeight: 'bold' }}>
            {data.description}
          </Text>
        </View>
        <View style={{ paddingVertical: 10, paddingHorizontal: 20 }}>
          <Card style={{ ...CardStyles.card, paddingHorizontal: 5, paddingVertical: 5 }}>
            {checkList?.map((item) => (
              <CheckListItem key={item.id} itemInfo={item} />
            ))}
            {!checkList?.length && (
            <Text>
              Чеклистов нет
            </Text>
            )}

          </Card>
        </View>

      </Content>
    </PagesBackground>
  );
};
export default CheckLists;
