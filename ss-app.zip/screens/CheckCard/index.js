import React, { useState } from 'react';
import {
  View, Text, Content, Card, Textarea, Button,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import AppCardStyles from '../../styles/appCard';
import CardStyles from '../../styles/card';
import CameraWrapper from '../../components/CameraWrapper';
import PagesBackground from '../../components/PagesBackground';

const CheckCard = ({ navigation }) => {
  const [image, setImage] = useState('');
  const [cameraOpen, setCameraOpen] = useState(false);
  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  return (
    <CameraWrapper open={cameraOpen}>
      <PagesBackground>
        <Content style={{ height: '100%' }}>
          <View style={{ ...AppCardStyles.header, justifyContent: 'flex-end', paddingHorizontal: 20 }}>
            <TouchableOpacity style={AppCardStyles.backButton} onPress={() => navigation.goBack()}>
              <MaterialIcons name="arrow-back" size={30} color="black" />
            </TouchableOpacity>
            <Button style={{ borderRadius: 10 }}>
              <Text>
                Начать
              </Text>
            </Button>
          </View>
          <View style={{ ...AppCardStyles.card }}>
            <Card style={AppCardStyles.card}>
              <Text style={CardStyles.number}>
                № 3446
              </Text>
              <Text style={{ fontWeight: 'bold' }}>
                АО "РАЙФФАЙЗЕНБАНК" ДО Отделение Речной вокзал,
                Санкт-петербург,М. Балканская ул.,д.26
              </Text>
              <Text style={CardStyles.date}>
                Выполнить до: 27.10.2020 до 23:00
              </Text>
              <TouchableOpacity onPress={() => navigation.navigate('CheckLists')}>
                <Text style={{ color: '#b849b9', marginVertical: 10, fontSize: 18 }}>
                  Чек-листы (27/80)
                </Text>
              </TouchableOpacity>
              <Text style={{ color: '#31afe6', fontWeight: 'bold', fontSize: 18 }}>Ответственные: Иванов И.И.</Text>
              <Text style={{ color: '#31afe6', fontWeight: 'bold', fontSize: 18 }}>От заказчика: Сидоров М.К.</Text>
              <View style={{ marginTop: 20 }}>
                <View style={{ flexDirection: 'row' }}>
                  <TouchableOpacity onPress={pickImage}>
                    <MaterialIcons name="attach-file" size={35} color="black" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => setCameraOpen(true)}>
                    <MaterialIcons name="photo-camera" size={35} color="black" />
                  </TouchableOpacity>
                </View>
                <Textarea
                  bordered
                  style={{
                    paddingHorizontal: 10, marginBottom: 10, paddingVertical: 5, backgroundColor: '#fff', height: 120, borderRadius: 10,
                  }}
                />
                <Button style={{ ...AppCardStyles.addButton, marginRight: 0 }}>
                  <Text>
                    Добавить
                  </Text>
                </Button>
              </View>
            </Card>

          </View>
        </Content>
      </PagesBackground>
    </CameraWrapper>
  );
};

export default CheckCard;
