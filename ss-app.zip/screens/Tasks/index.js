import React, { useEffect } from 'react';

import {
  View, Content,
} from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import { RefreshControl } from 'react-native';
import Task from '../../components/Task';
import * as PageActions from '../../redux/pages/pages.actions';
import ContainerStyles from '../../styles/container';
import PagesBackground from '../../components/PagesBackground';
import { getTasksStart } from '../../redux/tasks/tasks.actions';

const Tasks = ({ navigation }) => {
  const dispatch = useDispatch();
  const token = useSelector((state) => state.user.token);
  const tasks = useSelector((state) => state.tasks.items);
  const isLoading = useSelector((state) => state.pages.loading);
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      dispatch(PageActions.changeRoute('Tasks'));
    });
    return unsubscribe;
  }, [navigation]);
  useEffect(() => {
    dispatch(getTasksStart(token));
  }, []);

  return (
    <PagesBackground tasks>
      <Content refreshControl={<RefreshControl refreshing={isLoading} onRefresh={() => dispatch(getTasksStart(token))} />} style={{ paddingVertical: 10, boxSizing: 'border-box' }}>
        <View style={ContainerStyles.root}>
          {tasks.map((item) => <Task navigation={navigation} taskInfo={item} key={item.id} />)}
        </View>

      </Content>
    </PagesBackground>
  );
};

export default Tasks;
