import React, { useEffect } from 'react';
import { Content } from 'native-base';
import { useDispatch } from 'react-redux';

import ItemPreview from '../../components/ItemPreview';

import * as PageActions from '../../redux/pages/pages.actions';

import PagesBackground from '../../components/PagesBackground';

const Desktop = ({ navigation }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      dispatch(PageActions.changeRoute('Desktop'));
    });
    return unsubscribe;
  }, [navigation]);

  return (

    <PagesBackground desktop>
      <Content>
        <ItemPreview navigation={navigation} task />
        <ItemPreview navigation={navigation} app />
        <ItemPreview navigation={navigation} app />
        <ItemPreview navigation={navigation} check />
        <ItemPreview navigation={navigation} app />
        <ItemPreview navigation={navigation} app />
        <ItemPreview navigation={navigation} check />
        <ItemPreview navigation={navigation} task />
        <ItemPreview navigation={navigation} app />
        <ItemPreview navigation={navigation} task />
        <ItemPreview navigation={navigation} app />
      </Content>
    </PagesBackground>

  );
};

export default Desktop;
