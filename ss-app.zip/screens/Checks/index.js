import React, { useEffect } from 'react';
import { Content } from 'native-base';
import { useDispatch } from 'react-redux';
import Check from '../../components/Check';
import * as PageActions from '../../redux/pages/pages.actions';
import PagesBackground from '../../components/PagesBackground';

const Checks = ({ navigation }) => {
  const dispatch = useDispatch();
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      dispatch(PageActions.changeRoute('Checks'));
    });
    return unsubscribe;
  }, [navigation]);
  return (
    <PagesBackground>
      <Content>
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
        <Check navigation={navigation} />
      </Content>
    </PagesBackground>

  );
};

export default Checks;
