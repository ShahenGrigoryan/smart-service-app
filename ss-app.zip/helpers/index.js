export const getTime = (date) => {
  const trueDate = new Date(date);
  const hours = trueDate.getHours();
  const minutes = trueDate.getMinutes() < 10 ? `0${trueDate.getMinutes()}` : trueDate.getMinutes();
  return `${hours}:${minutes}`;
};

export const getDate = (date) => {
  const trueDate = new Date(date);
  const day = trueDate.getDate() < 10 ? `0${trueDate.getDate()}` : trueDate.getDate();
  const month = trueDate.getMonth() < 10 ? `0${trueDate.getMonth()}` : trueDate.getMonth();
  const year = trueDate.getFullYear();
  return `${day}.${month}.${year}`;
};
