import axios from 'axios';

const baseUrl = 'https://apitest.mysmartservice.com/api/v1';
const get = (token, url) => axios.get(url, {
  headers: {
    Authorization: `Bearer: ${token}`,
  },
});

export const getTickets = async (token) => {
  const ticketsUrl = `${baseUrl}/tickets`;
  return get(token, ticketsUrl);
};

export const getCurrentTicket = async (token, id) => {
  console.log('ticket id',id)
  const ticketUrl = `${baseUrl}/tickets/${id}`;
  return get(token, ticketUrl);
};

export const createTicketComment = async (token, ticketId, comment) => {
  const url = `${baseUrl}/tickets/${ticketId}/ticket_comments`;
  return axios.post(url, {
    ticket_comment: {
      comment,
    },
  }, {
    headers: {
      Authorization: `Bearer: ${token}`,
      'Content-type': 'application/json',
    },
  });
};

export const getTicketComments = async (token, ticketId) => {
  const commentsUrl = `${baseUrl}/tickets/${ticketId}/ticket_comments`;
  return get(token, commentsUrl);
};

export const updateCheckListItem = async ({
  token, ticketTodoId, todoItemId, completed_at,
}) => {
  const url = `${baseUrl}/ticket_todos/${ticketTodoId}/ticket_todo_items/${todoItemId}`;

  return axios.put(url, {
    completed_at: completed_at || null,
  }, {
    headers: {
      Authorization: `Bearer: ${token}`,
      'Content-type': 'application/json',
    },
  });
};

export const updateTicket = async ({ token, id, body }) => {
  console.log(token);
  const url = `${baseUrl}/tickets/${id}`;
  return axios.put(url, {
    body: JSON.stringify(body),
    headers: {
      Authorization: `Bearer: ${token}`,
      'Content-type': 'application/json',
    },
  });
};
