import React, { useState } from 'react';
import {
  View, CheckBox, Text, Card,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { Entypo } from '@expo/vector-icons';
import { useDispatch, useSelector } from 'react-redux';
import { updateCheckListItemStart } from '../redux/tasks/tasks.actions';

const CheckListItem = ({ itemInfo }) => {
  const token = useSelector((state) => state.user.token);
  const { checkListLoading } = useSelector((state) => state.tasks);
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const updateTodoItem = ({ todoItemId, completed_at }) => {
    dispatch(updateCheckListItemStart({
      token,
      taskTodoId: itemInfo.id,
      todoItemId,
      completed_at: !completed_at
        ? new Date(Date.now()).toISOString() : null,
    }));
  };
  return (
    <Card style={{ paddingHorizontal: 5 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ width: '15%' }}>
          <CheckBox disabled={checkListLoading} />
        </View>
        <TouchableOpacity style={{ paddingVertical: 10 }} onPress={() => setOpen(!open)}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ width: '83%' }}>
              {itemInfo?.todo_template?.name}
            </Text>
            {open ? (<Entypo name="chevron-down" size={24} color="black" />) : (
              <Entypo name="chevron-right" size={24} color="black" />
            )}
          </View>
        </TouchableOpacity>
      </View>
      {open && (
      <View style={{ paddingHorizontal: '5%', paddingBottom: 10 }}>
        {itemInfo?.task_todo_items?.map((todoItem) => (
          <TouchableOpacity
            onPress={() => updateTodoItem({
              todoItemId: todoItem?.id,
              completed_at: todoItem.completed_at,
            })}
            key={todoItem.id}
            style={{ flexDirection: 'row', alignItems: 'center' }}
          >
            <View style={{ width: '15%' }}>
              <CheckBox
                disabled={checkListLoading}
                checked={!!todoItem.completed_at}
                onPress={() => updateTodoItem({
                  todoItemId: todoItem?.id,
                  completed_at: todoItem.completed_at,
                })}
              />
            </View>
            <View style={{ paddingVertical: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={{ width: '95%' }}>
                  {todoItem?.todo_item?.name}
                </Text>
              </View>
            </View>

          </TouchableOpacity>
        ))}

      </View>
      )}

    </Card>
  );
};

export default CheckListItem;
