import React, { createRef, useEffect, useState } from 'react';
import { Camera } from 'expo-camera';
import { View } from 'native-base';
import { TouchableOpacity } from 'react-native';
import { Feather, FontAwesome5, FontAwesome } from '@expo/vector-icons';
import CameraStyles from '../styles/camera';

const CameraWrapper = ({ open, children }) => {
  let camera = createRef();
  const [hasPermission, setHasPermission] = useState(null);
  const [type, setType] = useState(Camera.Constants.Type.back);
  // useEffect(() => {
  //   (async () => {
  //     const { status } = await Camera.requestPermissionsAsync();
  //     setHasPermission(status === 'granted');
  //   })();
  //   (async () => {
  //     const ratios = await camera.getSupportedRatiosAsync();
  //   })();
  // }, []);

  const takePic = async () => {
    if (camera) {
      const photo = await camera.takePictureAsync();
    }
  };

  const changeType = () => {
    setType(
      type === Camera.Constants.Type.back
        ? Camera.Constants.Type.front
        : Camera.Constants.Type.back,
    );
  };
  return (
    <>
      {open && hasPermission
        ? (
          <Camera
            ratio="16:12"
            flashMode="on"
            style={CameraStyles.root}
            type={type}
            ref={(ref) => {
              camera = ref;
            }}
          >
            <View style={CameraStyles.toolbar}>
              <TouchableOpacity onPress={changeType}>
                <Feather name="rotate-cw" size={40} color="white" />
              </TouchableOpacity>
              <TouchableOpacity onPress={takePic}>
                <FontAwesome5 name="camera" size={40} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity>
                <FontAwesome name="bolt" size={40} color="#fff" />
              </TouchableOpacity>

            </View>

          </Camera>
        ) : children}
    </>
  );
};
// <View
//     style={{
//         flex: 1,
//         backgroundColor: 'transparent',
//         flexDirection: 'row',
//     }}>
//     <TouchableOpacity
//         style={{
//             flex: 0.1,
//             alignSelf: 'flex-end',
//             alignItems: 'center',
//         }}
//         onPress={() => {
//             setType(
//                 type === Camera.Constants.Type.back
//                     ? Camera.Constants.Type.front
//                     : Camera.Constants.Type.back
//             );
//         }}>
//         <Feather name="rotate-cw" size={24} color="white"/>
//     </TouchableOpacity>
//     <TouchableOpacity onPress={snap}>
//         <Text>Take a pic</Text>
//     </TouchableOpacity>
// </View>

export default CameraWrapper;
