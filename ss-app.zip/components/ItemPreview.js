import React from 'react';
import { View, Card, Text } from 'native-base';
import { TouchableOpacity } from 'react-native';
import { useDispatch } from 'react-redux';
import ItemPreviewStyles from '../styles/itemPreview';
import * as PageActions from '../redux/pages/pages.actions';

const ItemPreview = ({ app, check, navigation }) => {
  const dispatch = useDispatch();
  const color = app ? '#24b24e' : check ? '#04a3e8' : '#ff8028';
  const link = app ? 'ApplicationCard' : check ? 'CheckCard' : 'TaskCard';
  const goTo = () => {
    navigation.navigate(link);
    dispatch(PageActions.changeRoute(link));
  };

  return (

    <View style={ItemPreviewStyles.root}>
      <View style={ItemPreviewStyles.dateView}>
        <Text style={{ ...ItemPreviewStyles.week, color }}>
          пн
        </Text>
        <Text style={{ ...ItemPreviewStyles.day, color }}>
          14
        </Text>
      </View>
      <TouchableOpacity activeOpacity={0.5} style={ItemPreviewStyles.cardWrapper} onPress={goTo}>
        <Card style={{ ...ItemPreviewStyles.card, borderColor: color }}>
          <Text style={ItemPreviewStyles.cardText}>
            Обсуждение вариантов разви...
          </Text>
          <Text style={ItemPreviewStyles.cardTime}>
            11:00 - 12:00
          </Text>
        </Card>
      </TouchableOpacity>

    </View>
  );
};

export default ItemPreview;
