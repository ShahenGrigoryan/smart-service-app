import React from 'react';
import { Spinner } from 'native-base';
import { View } from 'react-native';
import LoaderStyles from '../styles/loader';

const Loader = ({ noIcon }) => (
  <View style={LoaderStyles.root}>
    {!noIcon && <Spinner />}
  </View>
);
export default Loader;
