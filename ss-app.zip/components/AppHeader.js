import React from 'react';
import {
  Button, Header, Text,
} from 'native-base';
import { Image, TouchableOpacity, View } from 'react-native';
import styled from 'styled-components';
import { MaterialCommunityIcons, AntDesign } from '@expo/vector-icons';

import { useSelector } from 'react-redux';
import SideMenuStyles from '../styles/sideMenu';
import LogoWhite from '../assets/images/LogoWhite.png';
import HeaderStyles from '../styles/header';
import ComponentsBackground from './ComponentsBackground';
import FilterStyles from '../styles/desktopFilter';

const AppHeader = ({ menuOpen }) => {
  const state = useSelector((state) => state);
  const isDesktop = state.pages.route === 'Desktop';
  const isTasks = state.pages.route === 'Tasks';
  return (
    <ComponentsBackground>
      <Header style={{ ...HeaderStyles.root, elevation: isDesktop || isTasks ? 0 : 1 }}>
        <TouchableOpacity
          activeOpacity={0.5}
          style={SideMenuStyles.burgerButton}
          onPress={menuOpen}
        >
          <MaterialCommunityIcons name="menu" size={35} color="#fff" />
        </TouchableOpacity>
        <Image source={LogoWhite} style={{ width: 15, height: 15 }} />
        <HeaderMainText>
          SMART SERVICE
        </HeaderMainText>
        <HeaderSecText>
          Будь эффективнее
        </HeaderSecText>
        <SearchView>
          <SearchIcon activeOpacity={0.5}>
            <AntDesign name="search1" size={20} color="#fff" />
          </SearchIcon>
        </SearchView>
      </Header>
      {isDesktop && (
        <View style={FilterStyles.root}>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Все
            </Text>
          </Button>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Сегодня
            </Text>
          </Button>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Alarm
            </Text>
          </Button>
        </View>
      )}
      {isTasks && (
        <View style={FilterStyles.root}>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Мои
            </Text>
          </Button>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Поручил
            </Text>
          </Button>
          <Button bordered style={FilterStyles.allButton}>
            <Text style={FilterStyles.allText}>
              Наблюдаю
            </Text>
          </Button>
        </View>
      )}
    </ComponentsBackground>
  );
};

const HeaderMainText = styled.Text`
  font-size: 15px;
  margin-bottom: 1px;
  color: #fff
`;
const HeaderSecText = styled.Text`
  font-size: 8px;
  letter-spacing: 2px;
  color: #fff
`;

const SearchView = styled.View`
  position: absolute;
  width: 100%;
  flex-direction: row;
  z-index: 0;
  justify-content: flex-end;
  right: 0
`;
const SearchIcon = styled.TouchableOpacity`
  padding-vertical: 15px;
  width: 50px;
  justify-content: center;
  align-items: center;

`;

export default AppHeader;
