import React from 'react';
import {
  Card, CardItem, Text, View,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { useDispatch } from 'react-redux';
import CardStyles from '../styles/card';
import * as PageActions from '../redux/pages/pages.actions';

const Check = ({ navigation }) => {
  const dispatch = useDispatch();
  const goTo = () => {
    navigation.navigate('CheckCard');
    dispatch(PageActions.changeRoute('Accruals'));
  };
  return (
    <TouchableOpacity activeOpacity={0.5} style={CardStyles.cardRoot} onPress={goTo}>
      <Card style={{ ...CardStyles.appCard, borderColor: '#24b24e' }}>
        <CardItem style={CardStyles.cardHeader}>
          <Text style={CardStyles.number}>
            № 3446
          </Text>
          <View style={CardStyles.headerView}>
            <Text style={CardStyles.title} />

          </View>
          <Text style={CardStyles.date}>
            Плановая дата проверки: 27.10.2020 до 23:00
          </Text>
          <Text style={CardStyles.bodyText}>
            АО "РАЙФФАЙЗЕНБАНК" ДО Отделение Речной вокзал,
            Санкт-петербург,М. Балканская ул.,д.26
          </Text>
        </CardItem>

      </Card>
    </TouchableOpacity>
  );
};

export default Check;
