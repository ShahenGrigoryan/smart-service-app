import React from 'react';
import {
  SafeAreaView, View, Image, TouchableOpacity,
} from 'react-native';
import { Text, Button } from 'native-base';
import { AntDesign } from '@expo/vector-icons';

import { useDispatch, useSelector } from 'react-redux';
import SideMenuStyles from '../styles/sideMenu';
import * as UserActions from '../redux/user/user.actions';
import * as RootNavigation from '../RootNavigation';
import ComponentsBackground from './ComponentsBackground';
import * as PageActions from '../redux/pages/pages.actions';

const SideMenuContent = ({ closeDrawer }) => {
  const dispatch = useDispatch();
  const state = useSelector((state) => state);
  const token = state.user.token;
  const avatarUri = { uri: state.user?.avatar ? state.user.avatar : 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.vexels.com%2Fpng-svg%2Fpreview%2F129733%2Fcasual-male-avatar-silhouette&psig=AOvVaw0XAbyoUt28v5Xq6BOcMRzm&ust=1609079414065000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJCeoY3u6-0CFQAAAAAdAAAAABAD' };
  const logout = () => {
    closeDrawer();
    dispatch(UserActions.logout(token));
  };
  return (
    <SafeAreaView style={{ height: '100%' }}>
      <ComponentsBackground>
        <View style={SideMenuStyles.userView}>
          <Image source={avatarUri} style={SideMenuStyles.avatar} />
          <Text style={SideMenuStyles.name}>{state?.user?.name}</Text>
          <Text style={SideMenuStyles.tel}>
            {state?.user?.phone}
          </Text>
        </View>
      </ComponentsBackground>
      <View style={SideMenuStyles.ratingView}>
        <View style={SideMenuStyles.ratingTextView}>
          <Text style={SideMenuStyles.ratingText}>
            Мой рейтинг
          </Text>
          <Text style={SideMenuStyles.ratingText}>
            4.7
          </Text>
        </View>
        <TouchableOpacity activeOpacity={0.5} style={SideMenuStyles.ratingInfoButton}>
          <AntDesign name="infocirlceo" size={24} color="#2b9f98" />
        </TouchableOpacity>

      </View>
      <Button
        style={{ marginLeft: 15, borderRadius: 10 }}
        onPress={() => {
          RootNavigation.navigate('Accruals');
          dispatch(PageActions.changeRoute('Accruals'));
          closeDrawer();
        }}
      >
        <Text style={{ fontSize: 14, color: '#fff' }}>
          Начисления
        </Text>
      </Button>
      <Button
        onPress={logout}
        style={{
          position: 'absolute', bottom: 10, left: 15, borderRadius: 10,
        }}
      >
        <Text style={{ fontSize: 12 }}>
          Выход
        </Text>
      </Button>
    </SafeAreaView>
  );
};

export default SideMenuContent;
