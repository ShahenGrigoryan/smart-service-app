import styled from 'styled-components';

export const HeaderMainText = styled.Text`
  font-size: 15px;
  margin-bottom: 1px;
  color: #fff
`;
export const HeaderSecText = styled.Text`
  font-size: 8px;
  letter-spacing: 2px;
  color: #fff
`;
