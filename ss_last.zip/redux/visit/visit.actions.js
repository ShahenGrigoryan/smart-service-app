export const SET_NOT_FIRST = 'SET_NOT_FIRST';

export const setNotFirst = () => ({
  type: SET_NOT_FIRST,
});
