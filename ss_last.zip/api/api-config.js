export const baseUrl = 'https://api.terra-security.ru/api/v1';
